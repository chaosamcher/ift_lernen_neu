import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*
 class GreetBavarianIOKtTest {

@Test
 fun f() {
  assertEquals(9,f(3))
 }
}